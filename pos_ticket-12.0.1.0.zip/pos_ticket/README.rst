POS Ticket v11
==============

This module will add company logo & company info in POS receipt. Also it will print the customer name
in the receipt if the customer is selected.
Default POS logo will be replaced by the company logo in POS status bar

Credits
=======
Cybrosys Techno Solutions

Author
------
* Niyas Raphy <niyas@cybrosys.in>
