Employee Time Clock
======================

Find all informations here: <https://apps.openerp.com/apps/modules/11.0/hr_employee_time_clock>
