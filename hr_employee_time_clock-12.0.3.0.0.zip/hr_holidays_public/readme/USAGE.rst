For adding public holidays:

#. Go to the menu *Leaves > Public Holidays > Public Holidays*.
#. Create your public holidays.

For using public holidays on leaves:

#. Go to *Leaves > Dashboard*.
#. Select dragging on the calendar the days you want to be on leave, or go
   to the form view for selecting start and end dates.
#. Select the proper "Leave Type" that has "Exclude Public Holidays" checked.
#. If no leave type is yet specified, then default configuration is to exclude
   public holidays.
#. The number of days will be computed excluding public holidays that match the
   selected employee, including global, country and state holidays.
#. If no employee is yet selected, only global holidays will be taken into
   account.
