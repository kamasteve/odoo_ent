* Michael Telahun Makonnen <mmakonnen@gmail.com>
* Fekete Mihai <feketemihai@gmail.com>
* Nikolina Todorova <nikolina.todorova@initos.com>
* Alexis de Lattre <alexis.delattre@akretion.com>
* Salton Massally (iDT Labs) <smassally@idtlabs.sl>
* Ivan Yelizariev <yelizariev@it-projects.info>
* Bassirou Ndaw <b.ndaw@ergobit.org>
* `Tecnativa <https://www.tecnativa.com>`__:

  * Pedro M. Baeza

* `Brainbean Apps <https://brainbeanapps.com>`__:

  * Alexey Pelykh <alexey.pelykh@brainbeanapps.com>
